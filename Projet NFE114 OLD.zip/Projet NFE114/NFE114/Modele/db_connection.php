<?php
session_start();

// //Note : can't figure why I cant call this function in the db_intel.php file
// function db_connect()
// {
//   try
//   {
//     $db = new PDO ('mysql:host=localhost;dbname=nfe114;charset=utf8', 'root', 'root');
//   }
//   catch(Exception $e)
//   {
//     die('Erreur : ' . $e->getMessage());
//   }
// }
?>

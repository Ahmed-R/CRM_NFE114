<?php
session_start();

  class Coorclt
  {
    private $_nom = "Steria";

    function GetNom()
    {
      echo $this->_nom;
    }
  }

?>

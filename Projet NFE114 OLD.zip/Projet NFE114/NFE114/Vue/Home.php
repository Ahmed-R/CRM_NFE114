<?php
session_start();
?>
<html>
<head> <title>Home - Page d'accueil</title></head>
<style> body {margin: 5%;}</style>
<style> table{border: 1px solid black;}</style>
<style> td{text-align: center;}</style>
<body>
  <p> Bonjour <?php echo $_SESSION['login'] ;?> </p>
  <p><a href="nouveau_client.php">Formulaire de nouveau client</a></p>
  <p>Ci-dessous, votre portefeuille de clients : </p>

  <?php
    //Connection to the db
    try {
        $db = new PDO ('mysql:host=localhost;dbname=nfe114;charset=utf8', 'root', 'root');
      }
    catch(Exception $e) {
        die('Erreur : ' . $e->getMessage());
      }
      //if the user is not the administrator, we display only his clients.
      if ($_SESSION['login'] != "administrateur") {
        $req = $db->prepare('SELECT nom FROM bdd_clt_gestion WHERE resp_compte = ?');
        $req->execute(array($_SESSION['login']));
      }
      //if the request is sent by the admin, we display all the clients.
      else {
        $req = $db->query('SELECT nom FROM bdd_clt_gestion');
      }
    while ($donnee = $req->fetch()) { ?>
    <section>
      <table>
        <tr>
          <td>
            <?php echo $donnee['nom']; ?><br>
            <form action="fiche_coor_clt.php" method="POST">
              <input type="hidden" name="clt_name" value="<?php echo $donnee['nom'];?>">
              <input type="submit" value="Acceder à la fiche de Coordonnées de ce client">
            </form>
            <form action="fiche_gestion_clt.php" method="POST">
              <input type="hidden" name="clt_name" value="<?php echo $donnee['nom'];?>">
              <input type="submit" value="Acceder à la fiche de Gestion de ce client">
            </form>
            <form action="voir_devis.php" method="POST">
              <input type="hidden" name="clt_name" value="<?php echo $donnee['nom'];?>">
              <input type="submit" value="voir les devis de ce client">
            </form> </td> </tr> </table> </section>
  <?php
    }
  ?>
</body></html>

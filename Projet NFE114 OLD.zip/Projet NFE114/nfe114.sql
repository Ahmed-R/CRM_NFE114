-- phpMyAdmin SQL Dump
-- version 4.4.1.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost:8889
-- Généré le :  Sam 20 Juin 2015 à 13:46
-- Version du serveur :  5.5.42
-- Version de PHP :  5.6.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `nfe114`
--

-- --------------------------------------------------------

--
-- Structure de la table `bdd_clt`
--

CREATE TABLE `bdd_clt` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_clt`
--

INSERT INTO `bdd_clt` (`id`, `nom`) VALUES
(1, 'Steria'),
(2, 'Microsoft'),
(3, 'Apple'),
(4, 'Google');

-- --------------------------------------------------------

--
-- Structure de la table `bdd_clt_coor`
--

CREATE TABLE `bdd_clt_coor` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tel` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_clt_coor`
--

INSERT INTO `bdd_clt_coor` (`id`, `nom`, `adresse`, `email`, `tel`) VALUES
(1, 'Steria', '1 rue de Steria', 'vincentparis@steria.com', 111111111),
(2, 'Microsoft', '2 boulevard de microsoft', 'billgates@microsoft.com', 222222222),
(3, 'Apple', '3 Avenue d''Apple', 'timcook@apple.com', 333333333),
(4, 'Google', '4 chemin de Google ', 'larrypage@gmail.com', 444444444);

-- --------------------------------------------------------

--
-- Structure de la table `bdd_clt_devis`
--

CREATE TABLE `bdd_clt_devis` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `responsable_compte` varchar(255) NOT NULL,
  `date_devis` date NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_clt_devis`
--

INSERT INTO `bdd_clt_devis` (`id`, `nom`, `responsable_compte`, `date_devis`, `description`) VALUES
(1, 'Google', 'ahmed', '2015-06-16', 'Vente d''un pc complet avec 2 ecrans'),
(2, 'Apple', 'zack', '2015-06-06', 'Vente de 2 pc complets sans souris'),
(3, 'Google', 'ahmed', '2015-03-19', 'Vente de 3 pc complets');

-- --------------------------------------------------------

--
-- Structure de la table `bdd_clt_gestion`
--

CREATE TABLE `bdd_clt_gestion` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `resp_compte` varchar(255) NOT NULL,
  `resp_equipe` varchar(255) NOT NULL,
  `date_dern_contact` date NOT NULL,
  `premium` tinytext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_clt_gestion`
--

INSERT INTO `bdd_clt_gestion` (`id`, `nom`, `resp_compte`, `resp_equipe`, `date_dern_contact`, `premium`) VALUES
(1, 'Steria', 'Zack', 'Jack', '2015-05-01', 'non'),
(2, 'Microsoft', 'Ahmed', 'Albert', '2015-04-13', 'non'),
(3, 'Apple', 'Zack', 'Jack', '2015-05-05', 'oui'),
(4, 'Google', 'Ahmed', 'Albert', '2015-03-18', 'oui');

-- --------------------------------------------------------

--
-- Structure de la table `bdd_items`
--

CREATE TABLE `bdd_items` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `date_devis` date NOT NULL,
  `tour` int(11) NOT NULL,
  `ecran` int(11) NOT NULL,
  `clavier` int(11) NOT NULL,
  `souris` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_items`
--

INSERT INTO `bdd_items` (`id`, `nom`, `date_devis`, `tour`, `ecran`, `clavier`, `souris`) VALUES
(1, 'google', '2015-06-16', 1, 2, 1, 1),
(2, 'Apple', '2015-06-06', 2, 2, 2, 0),
(4, 'Google', '2015-03-19', 3, 3, 3, 3);

-- --------------------------------------------------------

--
-- Structure de la table `bdd_login`
--

CREATE TABLE `bdd_login` (
  `id` int(11) NOT NULL COMMENT 'id de l''enregistrement',
  `login` varchar(255) NOT NULL COMMENT 'login user',
  `mdp` varchar(255) NOT NULL COMMENT 'mdp user',
  `blocked` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bdd_login`
--

INSERT INTO `bdd_login` (`id`, `login`, `mdp`, `blocked`) VALUES
(1, 'administrateur', 'pass administrateur', 0),
(2, 'manager', 'pass manager', 0),
(3, 'zack', 'pass zack', 0),
(4, 'ahmed', 'pass ahmed', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `bdd_clt`
--
ALTER TABLE `bdd_clt`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bdd_clt_coor`
--
ALTER TABLE `bdd_clt_coor`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bdd_clt_devis`
--
ALTER TABLE `bdd_clt_devis`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bdd_clt_gestion`
--
ALTER TABLE `bdd_clt_gestion`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bdd_items`
--
ALTER TABLE `bdd_items`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bdd_login`
--
ALTER TABLE `bdd_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bdd_clt`
--
ALTER TABLE `bdd_clt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `bdd_clt_coor`
--
ALTER TABLE `bdd_clt_coor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `bdd_clt_devis`
--
ALTER TABLE `bdd_clt_devis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `bdd_clt_gestion`
--
ALTER TABLE `bdd_clt_gestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `bdd_items`
--
ALTER TABLE `bdd_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `bdd_login`
--
ALTER TABLE `bdd_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id de l''enregistrement',AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
